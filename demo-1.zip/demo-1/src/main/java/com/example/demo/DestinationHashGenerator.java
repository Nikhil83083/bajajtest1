package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Random;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.DigestUtils;

@SpringBootApplication
public class DestinationHashGenerator {
    private static final int RANDOM_STRING_LENGTH = 8;

	public static void main(String[] args) {
		

        if (args.length != 3) {
            System.err.println("Usage: java -jar <Bajaj_test456-0.0.1-SNAPSHOT.jar> <240350000046> <C:\\Users\\Prime\\Desktop\\Nikhil_programs\\Programs1\\Practise_Study\\Bajaj_test456\\target>");
            System.exit(1);
        }

        String prnNumber = args[1];
        String jsonFilePath = args[2];

        try {
           
            String content = new String(Files.readAllBytes(Paths.get(jsonFilePath)));
            JSONObject jsonObject = new JSONObject(new JSONTokener(content));

          
            String destinationValue = findDestinationValue(jsonObject);

            if (destinationValue == null) {
                System.err.println("Key 'destination' not found in JSON.");
                System.exit(1);
            }

        
            String randomString = generateRandomString(RANDOM_STRING_LENGTH);

          
            String concatenatedString = prnNumber + destinationValue + randomString;

       
            byte[] md5Digest  = DigestUtils.md5Digest(concatenatedString.getBytes());

          
            System.out.println(md5Digest + ";" + randomString);

        } catch (IOException e) {
            System.err.println("Error reading JSON file: " + e.getMessage());
            System.exit(1);
        }
    
		
		SpringApplication.run(DestinationHashGenerator.class, args);
	}

	
	 private static String findDestinationValue(JSONObject jsonObject) {
		 
	        return findDestinationValueRecursive(jsonObject);
	    }

	    private static String findDestinationValueRecursive(JSONObject jsonObject) {
	        for (String key : jsonObject.keySet()) {
	            if ("destination".equals(key)) {
	                return jsonObject.getString(key);
	            }
	            Object value = jsonObject.get(key);
	            if (value instanceof JSONObject) {
	                String result = findDestinationValueRecursive((JSONObject) value);
	                if (result != null) {
	                    return result;
	                }
	            }
	        }
	        return null;
	    }

	    private static String generateRandomString(int length) {
	        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	        Random random = new SecureRandom();
	        StringBuilder sb = new StringBuilder(length);
	        for (int i = 0; i < length; i++) {
	            sb.append(characters.charAt(random.nextInt(characters.length())));
	        }
	        return sb.toString();
	    }
}



